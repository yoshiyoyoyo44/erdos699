"""Independent finite checks for the accompanying Erdős 699 continuation.

The mathematical proofs are in erdos699_even_digit_continuation.md.
These checks do not constitute a search of all counterexamples to Problem 699.
Python standard library only; run without -O.
"""
from math import gcd, isqrt
from pathlib import Path
import json


def valuation2(n):
    assert n > 0
    return (n & -n).bit_length() - 1


def primes_up_to(n):
    return [p for p in range(2, n + 1)
            if all(p % q for q in range(2, isqrt(p) + 1))]


def prime_divisors(n):
    result = []
    p = 2
    while p * p <= n:
        if n % p == 0:
            result.append(p)
            while n % p == 0:
                n //= p
        p += 1
    if n > 1:
        result.append(n)
    return result


def digit_sum(n, p):
    ans = 0
    while n:
        n, d = divmod(n, p)
        ans += d
    return ans


def audit_v1():
    total = admitted = prime1 = prime3 = 0
    nontrivial_odd_gcd = size_compatible = 0
    gcd_cache = {}
    for p in primes_up_to(101):
        if p == 2:
            continue
        powers = [p**a for a in range(25)]
        for r in range(1, 13):
            for s in range(1, 13):
                X = powers[r] + 1
                for b in range(13):
                    Y = powers[b] * (powers[s] + 1)
                    total += 1
                    if valuation2(X) != 1 or valuation2(Y) != 1:
                        continue
                    N = X + Y
                    if valuation2(N) < 3:
                        continue
                    admitted += 1
                    # These are exactly four powers; coefficients at overlap
                    # never exceed 2, so for odd p they have digit sum four.
                    assert digit_sum(N, p) == 4
                    C = gcd(X, Y) // 2   # C = epsilon * U in the proof.
                    if p % 4 == 1:
                        prime1 += 1
                        assert p % 8 == 5
                        assert (r + s) % 2 == 1
                        assert C == 1
                    else:
                        prime3 += 1
                        assert r % 2 == s % 2 == 0
                        d = gcd(r, s)
                        expected = (p**d + 1) // 2 if valuation2(r) == valuation2(s) else 1
                        assert C == expected
                        w = valuation2(p + 1)
                        if valuation2(r) == valuation2(s) or min(valuation2(r), valuation2(s)) >= 2:
                            assert b % 2 == 1
                            assert valuation2(N) == w + 1
                            assert p**3 >= 1 << (valuation2(N) - 2)
                        if C > 1:
                            nontrivial_odd_gcd += 1
                            # The factorization is only an extra small-range
                            # check; the general proof uses a square root of -1.
                            assert pow(p, d, 2*C) == 2*C-1
                            if C < 10**9:
                                key = (p, d)
                                if key not in gcd_cache:
                                    gcd_cache[key] = prime_divisors(C)
                                assert all(ell % 4 == 1 for ell in gcd_cache[key])
                    # Every actual counterexample satisfies this weaker
                    # consequence of M^3 < 2^(u-2), because p divides M.
                    if p**3 < 1 << (valuation2(N) - 2):
                        size_compatible += 1
                        assert C == 1
                        if p % 4 == 3:
                            assert b % 2 == 1
                            assert {valuation2(r), valuation2(s)} != {1}
                            assert min(valuation2(r), valuation2(s)) == 1
                            assert max(valuation2(r), valuation2(s)) >= 2
    return dict(total=total, admitted=admitted, prime1_mod4=prime1,
                prime3_mod4=prime3, nontrivial_odd_gcd=nontrivial_odd_gcd,
                necessary_size_compatible_cases=size_compatible,
                distinct_factorizations=len(gcd_cache))


def audit_large_v():
    total = high_u = normalized = strict_opposite = 0
    examples = []
    for p in primes_up_to(251):
        if p == 2 or valuation2(p + 1) < 2:
            continue
        v = valuation2(p + 1)
        x = 1 << v
        for r in range(1, 32, 2):
            for s in range(1, 32, 2):
                for b in range(32):
                    X = 1 + p**r
                    Y = p**b * (1 + p**s)
                    N = X + Y
                    total += 1
                    u = valuation2(N)
                    assert valuation2(X) == valuation2(Y) == v
                    d = gcd(r, s)
                    assert gcd(X, Y) == p**d + 1
                    if u <= 2*v:
                        continue
                    high_u += 1
                    assert r != s
                    R, S = r//d, s//d
                    assert (R + (-1)**b * S) % x == 0
                    assert max(R, S) >= x//2 + 1
                    if b % 2:
                        strict_opposite += 1
                        assert valuation2(r - s if r > s else s - r) == v
                        assert max(R, S) >= x + 1
                    quot = N // (p**d + 1)
                    kappa = quot >> valuation2(quot)
                    if kappa not in (1, 3):
                        continue
                    normalized += 1
                    assert digit_sum(N, p) == 4
                    assert kappa * (1 << (u-v+1)) > p**(d*(x//2))
                    if b % 2:
                        assert kappa * (1 << (u-v+1)) > p**(d*x)
                        assert u >= v*x + v - (2 if kappa == 1 else 4)
                    bound = v*(x//2) + v - (1 if kappa == 1 else 3)
                    assert u >= bound
                    if len(examples) < 20:
                        examples.append(dict(p=p, v=v, r=r, s=s, b=b,
                                             u=u, d=d, kappa=kappa))
    return dict(total=total, high_valuation_cases=high_u,
                opposite_parity_cases=strict_opposite,
                normalized_power_of_two_cases=normalized, examples=examples)


def audit_reciprocity():
    # Existing v>=2 argument: two primes 3 mod 4 cannot each have the
    # other as a quadratic residue. This is auxiliary, not a proof of QR.
    primes = [p for p in primes_up_to(997) if p % 4 == 3]
    pairs = 0
    for pos, p in enumerate(primes):
        for ell in primes[pos + 1:]:
            assert not (pow(ell, (p-1)//2, p) == 1 and
                        pow(p, (ell-1)//2, ell) == 1)
            pairs += 1
    return dict(prime_pairs=pairs)


def audit_thresholds():
    rows = []
    for v in range(2, 15):
        x = 1 << v
        R = (x - 1)**(x//2)
        # Strict Bernoulli inequality gives these exact binary lengths.
        assert R.bit_length() == v*(x//2)
        rows.append(dict(v=v, inherited_u_min=max(49, 4*v+14),
                         kappa1_u_min=v*(x//2)+v-1,
                         kappa3_u_min=v*(x//2)+v-3))
    return rows


if __name__ == '__main__':
    assert __debug__, 'Assertions must be enabled.'
    result = dict(
        status='PASS',
        scope='Finite checks of the stated lemmas; not a full counterexample search.',
        v1=audit_v1(),
        v_ge_2=audit_large_v(),
        reciprocity=audit_reciprocity(),
        thresholds=audit_thresholds(),
    )
    target = Path(__file__).with_name('verification_sparse_digits.json')
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
