"""Exact checks for erdos699_prime_power_obstructions_2026-09-14.md.

The all-u order theorems are proved in the note. The digit enumeration below
is a complete finite calculation in u, covering all possible prime bases
without a bound on the base and without factoring 2**u +/- 1.
Standard library only; assertions must be enabled.
"""
from math import gcd, isqrt
from pathlib import Path
import hashlib
import json
import time


def v2(n):
    assert n > 0
    return (n & -n).bit_length() - 1


def v3(n):
    assert n > 0
    ans = 0
    while n % 3 == 0:
        n //= 3
        ans += 1
    return ans


def primes_up_to(n):
    return [p for p in range(3, n+1, 2)
            if all(p % d for d in range(3, isqrt(p)+1, 2))]


def prime_factors(n):
    out = []
    d = 2
    while d*d <= n:
        if n % d == 0:
            out.append(d)
            while n % d == 0:
                n //= d
        d += 1
    if n > 1:
        out.append(n)
    return out


def order_v2(p, ell):
    """Exact 2-part of the multiplicative order, without factoring ell-1."""
    assert ell > 2 and p % ell != 0
    q = (ell-1) >> v2(ell-1)
    z = pow(p, q, ell)
    s = 0
    while z != 1:
        z = z*z % ell
        s += 1
        assert s <= v2(ell-1)
    return s


def audit_order_theorems():
    odd_order_cases = order_not_four_cases = 0
    examples = []
    for p in primes_up_to(43):
        for u in range(1, 17):
            for e in range(1, 5):
                n = (1 << u)*p**e
                delta = 3 if v3(n-1) == 1 else 1
                Q = (n-1)//delta
                t, h = v2(u), v2(e)
                if t >= h+2:
                    a, b = u//(1 << h), e//(1 << h)
                    assert a % 4 == 0 and b % 2 == 1
                    D = (1 << a)*p**b - 1
                    delta_D = gcd(D, delta)
                    C = D//delta_D
                    assert Q % C == 0 and C % 8 in (5, 7)
                    witness = [ell for ell in prime_factors(C)
                               if ell % 8 != 1]
                    assert witness
                    assert all(order_v2(p, ell) == 0 for ell in witness)
                    odd_order_cases += 1
                    if len(examples) < 8:
                        examples.append(dict(p=p,u=u,e=e,ell=witness[0],
                                             order_v2=0))
                if p % 3 == 1 and u > 3*e:
                    factors = prime_factors(Q)
                    witness = [ell for ell in factors
                               if order_v2(p,ell) <= 1]
                    assert witness
                    order_not_four_cases += 1
    return dict(odd_order_cases=odd_order_cases,
                order_not_divisible_by_four_cases=order_not_four_cases,
                examples=examples)


def integer_root(n, k):
    """Floor n**(1/k), with both defining inequalities checked exactly."""
    assert n >= 1 and k >= 1
    x = 1 << ((n.bit_length()+k-1)//k)
    while True:
        y = ((k-1)*x + n//x**(k-1))//k
        if y >= x:
            assert x**k <= n < (x+1)**k
            return x
        x = y


def four_digits(n, p):
    """Return the exponent multiset if the base-p digit sum is exactly 4."""
    total = pos = 0
    out = []
    while n:
        n, digit = divmod(n, p)
        total += digit
        if total > 4:
            return None
        out.extend([pos]*digit)
        pos += 1
    return out if total == 4 else None


def finite_all_base_certificate(max_u=1024):
    roots = bases = eligible_bases = 0
    hits = []
    per_gamma = []
    digest = hashlib.sha256()
    for gamma in (1, 3):
        gamma_roots = gamma_bases = 0
        for u in range(1, max_u+1):
            N = gamma << u
            Lmax = 0
            z = 1
            while 3*z <= N:
                z *= 3
                Lmax += 1
            assert 3**Lmax <= N < 3**(Lmax+1)
            seen = set()
            for L in range(4, Lmax+1):
                for leading in (1,2,3):
                    p = integer_root(N//leading, L)
                    roots += 1
                    gamma_roots += 1
                    # Record a reproducible digest of the exhaustive loop.
                    digest.update(f'{gamma},{u},{L},{leading},{p}\n'.encode())
                    if p < 3 or p % 2 == 0 or gcd(p,gamma) != 1 or p in seen:
                        continue
                    seen.add(p)
                    bases += 1
                    gamma_bases += 1
                    if N <= 4*p**3:
                        continue
                    eligible_bases += 1
                    es = four_digits(N,p)
                    if es is not None:
                        assert min(es) == 0 and max(es) >= 4
                        assert N == sum(p**a for a in es)
                        hits.append(dict(gamma=gamma,u=u,p=p,exponents=es))
            # L<4 cannot qualify when N>4*p^3 and the digit sum is four.
        per_gamma.append(dict(gamma=gamma,root_checks=gamma_roots,
                              distinct_bases_by_u=gamma_bases))
    assert hits == [dict(gamma=1,u=8,p=3,exponents=[0,1,2,5])]
    # The one relaxed solution has p=3, gamma=1. Genuine normalization
    # forces e>=2, already contradicting (gamma*p**e)^3 < 2**(u-2).
    assert 3**6 >= 1 << (8-2)
    return dict(max_u=max_u,base_upper_bound=None,
                roots_checked=roots,distinct_bases_by_u=bases,
                size_eligible_bases=eligible_bases,
                per_gamma=per_gamma,hits=hits,
                exhaustive_loop_sha256=digest.hexdigest(),
                genuine_normalized_parameter_hits=0)


def audit_root_coverage():
    """A separate direct scan checks the root coverage on a small rectangle."""
    checked = qualifying = 0
    for gamma in (1,3):
        for u in range(1,31):
            N=gamma << u
            for p in range(3,302,2):
                if gcd(p,gamma) != 1:
                    continue
                checked += 1
                es=four_digits(N,p)
                if es is None or N <= 4*p**3:
                    continue
                qualifying += 1
                L=max(es)
                leading=es.count(L)
                assert L >= 4 and 1 <= leading <= 3
                assert integer_root(N//leading,L) == p
    return dict(direct_pairs=checked,qualifying=qualifying)


if __name__ == '__main__':
    assert __debug__, 'Run without -O.'
    start=time.perf_counter()
    result=dict(status='PASS',order_theorems=audit_order_theorems(),
                independent_small_coverage=audit_root_coverage(),
                finite_certificate=finite_all_base_certificate())
    result['elapsed_seconds']=round(time.perf_counter()-start,3)
    target=Path(__file__).with_name('verification_prime_power_obstructions.json')
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
